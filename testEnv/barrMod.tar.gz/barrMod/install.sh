#!/bin/bash

# 安裝腳本 for gamemod (已編譯版本)
# 包含安裝動畫效果

# 顏色定義
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# 動畫字符
SPINNER=("⠋" "⠙" "⠹" "⠸" "⠼" "⠴" "⠦" "⠧" "⠇" "⠏")

# 顯示標題
show_title() {
    clear
    echo -e "${PURPLE}╔═══════════════════════════════════════╗${NC}"
    echo -e "${PURPLE}║     🎮 百家樂模擬安裝工具 v1.0.0       ║${NC}"
    echo -e "${PURPLE}╚═══════════════════════════════════════╝${NC}"
    echo ""
}

# 顯示進度條
progress_bar() {
    local duration=$1
    local message=$2
    local max_width=50
    
    echo -e "${CYAN}${message}${NC}"
    
    for ((i=0; i<=max_width; i++)); do
        percentage=$((i * 2))
        completed=$i
        remaining=$((max_width - i))
        
        # 繪製進度條
        bar="["
        for ((j=0; j<completed; j++)); do
            bar+="█"
        done
        for ((j=0; j<remaining; j++)); do
            bar+="░"
        done
        bar+="]"
        
        echo -ne "\r${CYAN}${bar} ${percentage}%${NC}"
        sleep "$duration"
    done
    echo -e "\r${GREEN}✓ ${message}完成！${NC}"
}

# 旋轉動畫
spinner() {
    local pid=$1
    local message=$2
    local delay=0.1
    local i=0
    
    while kill -0 $pid 2>/dev/null; do
        printf "\r${SPINNER[$i]} ${BLUE}${message}${NC}"
        i=$(( (i+1) % ${#SPINNER[@]} ))
        sleep $delay
    done
    printf "\r${GREEN}✓ ${message}完成！${NC}\n"
}

# 檢查執行檔
check_binary() {
    echo -e "${YELLOW}檢查執行檔...${NC}"
    
    if [ ! -f "gamemod" ]; then
        echo -e "${RED}錯誤: 找不到 gamemod 可執行檔${NC}"
        echo -e "${YELLOW}請先編譯程式：${NC}"
        echo -e "  gcc gamemod.c -o gamemod"
        exit 1
    fi
    
    if [ ! -x "gamemod" ]; then
        echo -e "${YELLOW}設定執行權限...${NC}"
        chmod +x gamemod &
        spinner $! "設定執行權限"
    fi
    
    # 測試執行檔
    echo -e "${YELLOW}測試執行檔...${NC}"
    ./gamemod --version > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ 執行檔測試通過${NC}"
        VERSION=$(./gamemod --version | head -1)
        echo -e "${BLUE}版本資訊: ${VERSION}${NC}"
    else
        echo -e "${YELLOW}⚠ 無法讀取版本資訊，但執行檔存在${NC}"
    fi
}

# 安裝到系統
install_to_system() {
    local target_dir="/usr/local/bin"
    local app_name="gamemod"
    
    echo -e "\n${YELLOW}正在安裝到系統目錄...${NC}"
    
    # 備份舊版本
    if [ -f "$target_dir/$app_name" ]; then
        backup_file="$target_dir/${app_name}.backup.$(date +%Y%m%d_%H%M%S)"
        echo -e "${YELLOW}備份舊版本...${NC}"
        cp "$target_dir/$app_name" "$backup_file" &
        spinner $! "備份舊版本"
        echo -e "${GREEN}✓ 已備份至: $backup_file${NC}"
    fi
    
    # 複製檔案
    echo -e "${YELLOW}安裝檔案...${NC}"
    cp gamemod "$target_dir/$app_name" &
    spinner $! "複製檔案"
    
    # 設定權限
    chmod 755 "$target_dir/$app_name" &
    spinner $! "設定權限"
    
    echo -e "${GREEN}✓ 已安裝到: $target_dir/$app_name${NC}"
}

# 安裝到用戶目錄
install_to_user() {
    local target_dir="$HOME/.local/bin"
    local app_name="gamemod"
    
    echo -e "\n${YELLOW}正在安裝到用戶目錄...${NC}"
    
    # 建立目錄
    if [ ! -d "$target_dir" ]; then
        mkdir -p "$target_dir" &
        spinner $! "建立目錄"
    fi
    
    # 備份舊版本
    if [ -f "$target_dir/$app_name" ]; then
        backup_file="$target_dir/${app_name}.backup.$(date +%Y%m%d_%H%M%S)"
        echo -e "${YELLOW}備份舊版本...${NC}"
        cp "$target_dir/$app_name" "$backup_file" &
        spinner $! "備份舊版本"
        echo -e "${GREEN}✓ 已備份至: $backup_file${NC}"
    fi
    
    # 複製檔案
    echo -e "${YELLOW}安裝檔案...${NC}"
    cp gamemod "$target_dir/$app_name" &
    spinner $! "複製檔案"
    
    # 設定權限
    chmod 755 "$target_dir/$app_name" &
    spinner $! "設定權限"
    
    # 檢查 PATH
    if [[ ":$PATH:" != *":$target_dir:"* ]]; then
        echo -e "\n${YELLOW}⚠ 注意: $target_dir 不在 PATH 環境變數中${NC}"
        echo -e "${BLUE}請將以下行加入 ~/.bashrc 或 ~/.bash_profile:${NC}"
        echo -e "${CYAN}export PATH=\"\$HOME/.local/bin:\$PATH\"${NC}"
        echo -e "\n${BLUE}或執行以下命令:${NC}"
        echo -e "${CYAN}echo 'export PATH=\"\$HOME/.local/bin:\$PATH\"' >> ~/.bashrc${NC}"
        echo -e "${CYAN}source ~/.bashrc${NC}"
    fi
    
    echo -e "${GREEN}✓ 已安裝到: $target_dir/$app_name${NC}"
}

# 顯示安裝完成訊息
show_completion() {
    echo -e "\n${PURPLE}╔═══════════════════════════════════════╗${NC}"
    echo -e "${PURPLE}║           🎉 安裝完成！              ║${NC}"
    echo -e "${PURPLE}╚═══════════════════════════════════════╝${NC}"
    
    echo -e "\n${GREEN}🎮 百家樂模擬已成功安裝！${NC}"
    echo -e "${BLUE}使用方式:${NC}"
    echo -e "  ${CYAN}gamemod${NC}              - 開始遊戲"
    echo -e "  ${CYAN}gamemod --help${NC}       - 顯示幫助"
    echo -e "  ${CYAN}gamemod --version${NC}    - 顯示版本"
    
    # 顯示測試命令
    echo -e "\n${YELLOW}測試安裝:${NC}"
    if command -v gamemod &> /dev/null; then
        gamemod --version
    else
        echo -e "${YELLOW}請重新開啟終端機或執行:${NC}"
        echo -e "${CYAN}source ~/.bashrc${NC}"
    fi
}

# 主安裝流程
main() {
    show_title
    
    # 步驟1: 檢查執行檔
    check_binary
    
    # 步驟2: 進度條動畫
    progress_bar 0.03 "準備安裝環境"
    
    # 步驟3: 選擇安裝位置
    echo -e "\n${YELLOW}選擇安裝位置:${NC}"
    echo -e "  ${CYAN}1${NC}) 系統安裝 (需要 sudo)"
    echo -e "  ${CYAN}2${NC}) 用戶安裝 (~/.local/bin)"
    echo -e "  ${CYAN}3${NC}) 當前目錄"
    echo -e "  ${CYAN}4${NC}) 取消安裝"
    
    read -p "$(echo -e ${BLUE}"請選擇 [1-4]: "${NC})" choice
    
    case $choice in
        1)
            if [ "$EUID" -ne 0 ]; then
                echo -e "\n${YELLOW}需要管理員權限，請輸入密碼:${NC}"
                sudo echo -e "${GREEN}✓ 權限確認${NC}"
            fi
            install_to_system
            ;;
        2)
            install_to_user
            ;;
        3)
            echo -e "\n${GREEN}✓ 將使用當前目錄的 gamemod${NC}"
            echo -e "${YELLOW}提示: 執行 ./gamemod 來啟動遊戲${NC}"
            show_completion
            exit 0
            ;;
        4)
            echo -e "\n${YELLOW}安裝已取消${NC}"
            exit 0
            ;;
        *)
            echo -e "\n${RED}無效選擇，安裝已取消${NC}"
            exit 1
            ;;
    esac
    
    # 顯示完成訊息
    show_completion
    
    # 清理選項
    echo -e "\n${YELLOW}是否要清理安裝檔案？${NC}"
    read -p "刪除當前目錄的 gamemod 檔案？[y/N]: " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -f gamemod &
        spinner $! "清理檔案"
        echo -e "${GREEN}✓ 已清理安裝檔案${NC}"
    fi
    
    echo -e "\n${GREEN}安裝程序完成！${NC}"
}

# 錯誤處理
trap 'echo -e "\n${RED}安裝中斷！${NC}"; exit 1' INT TERM

# 執行主程序
main