#!/bin/sh

# 解除安裝腳本 for gamemod (兼容 Alpine Linux ash)
# 包含動畫效果

# 顏色定義
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# 動畫字符
SPINNER="|/-\\"

# 顯示標題
show_title() {
    clear
    printf "${PURPLE}╔═══════════════════════════════════════╗${NC}\n"
    printf "${PURPLE}║     🗑️  百家樂模擬解除安裝工具          ║${NC}\n"
    printf "${PURPLE}╚═══════════════════════════════════════╝${NC}\n"
    printf "\n"
}

# 旋轉動畫 (簡化版，兼容 ash)
spinner() {
    local pid=$1
    local message=$2
    local delay=0.1
    local i=0
    
    while kill -0 $pid 2>/dev/null; do
        i=$(( (i+1) % 4 ))
        printf "\r%c ${BLUE}%s${NC}" "${SPINNER:$i:1}" "$message"
        sleep $delay
    done
    printf "\r${GREEN}✓ ${message}完成！${NC}\n"
}

# 顯示進度條 (簡化版，兼容 ash)
progress_bar() {
    local duration=$1
    local message=$2
    local max_width=50
    
    printf "${CYAN}%s${NC}\n" "$message"
    
    i=0
    while [ $i -le $max_width ]; do
        percentage=$((i * 2))
        completed=$i
        remaining=$((max_width - i))
        
        bar="["
        j=0
        while [ $j -lt $completed ]; do
            bar="$bar█"
            j=$((j+1))
        done
        j=0
        while [ $j -lt $remaining ]; do
            bar="$bar░"
            j=$((j+1))
        done
        bar="$bar]"
        
        printf "\r${CYAN}%s %d%%${NC}" "$bar" "$percentage"
        sleep "$duration"
        i=$((i+1))
    done
    printf "\r${GREEN}✓ ${message}完成！${NC}\n"
}

# 尋找安裝位置 (兼容 ash)
find_installation() {
    local app_name="gamemod"
    
    printf "${YELLOW}掃描安裝位置...${NC}\n"
    
    # 可能的安裝位置
    possible_paths="
        /usr/local/bin/$app_name
        /usr/bin/$app_name
        /bin/$app_name
        $HOME/.local/bin/$app_name
        $HOME/bin/$app_name
        /opt/gamemod/$app_name
        $(pwd)/$app_name
    "
    
    found_paths=""
    
    # 使用 IFS 處理換行
    old_IFS="$IFS"
    IFS='
    '
    for path in $possible_paths; do
        if [ -f "$path" ]; then
            # 檢查是否為可執行檔
            if file "$path" 2>/dev/null | grep -q "ELF\|executable"; then
                found_paths="$found_paths$path "
                printf "${GREEN}✓ 找到: %s${NC}\n" "$path"
            fi
        fi
    done
    IFS="$old_IFS"
    
    if [ -z "$found_paths" ]; then
        printf "${YELLOW}⚠ 未找到 gamemod 安裝${NC}\n"
        
        # 檢查是否在 PATH 中
        if command -v gamemod >/dev/null 2>&1; then
            which_path=$(which gamemod)
            printf "${GREEN}✓ 在 PATH 中找到: %s${NC}\n" "$which_path"
            found_paths="$which_path "
        fi
    fi
    
    # 返回結果
    echo "$found_paths"
}

# 解除安裝單個位置
uninstall_single() {
    local target_path="$1"
    local backup_dir="$HOME/.gamemod_backups"
    
    printf "\n${YELLOW}處理: %s${NC}\n" "$target_path"
    
    # 確認
    printf "${YELLOW}確定要移除這個檔案嗎？[y/N]: ${NC}"
    read -r reply
    case "$reply" in
        [Yy]*)
            # 繼續執行
            ;;
        *)
            printf "${BLUE}跳過: %s${NC}\n" "$target_path"
            return 0
            ;;
    esac
    
    # 建立備份目錄
    if [ ! -d "$backup_dir" ]; then
        mkdir -p "$backup_dir" &
        spinner $! "建立備份目錄"
    fi
    
    # 建立備份
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_file="$backup_dir/gamemod_${timestamp}_$(basename "$target_path")"
    printf "${YELLOW}建立備份...${NC}\n"
    cp "$target_path" "$backup_file" &
    spinner $! "備份檔案"
    
    # 移除檔案
    printf "${YELLOW}移除檔案...${NC}\n"
    case "$target_path" in
        /usr/*)
            if [ "$(id -u)" -ne 0 ]; then
                printf "${YELLOW}需要管理員權限...${NC}\n"
                if command -v sudo >/dev/null 2>&1; then
                    sudo rm -f "$target_path" &
                    spinner $! "移除系統檔案"
                else
                    printf "${RED}錯誤: 需要 sudo 但未安裝${NC}\n"
                    return 1
                fi
            else
                rm -f "$target_path" &
                spinner $! "移除檔案"
            fi
            ;;
        *)
            rm -f "$target_path" &
            spinner $! "移除檔案"
            ;;
    esac
    
    # 驗證移除
    if [ ! -f "$target_path" ]; then
        printf "${GREEN}✓ 已成功移除${NC}\n"
        printf "${BLUE}備份位置: %s${NC}\n" "$backup_file"
        return 0
    else
        printf "${RED}✗ 移除失敗${NC}\n"
        return 1
    fi
}

# 移除備份檔（可選）
cleanup_backups() {
    local backup_dir="$HOME/.gamemod_backups"
    
    if [ -d "$backup_dir" ]; then
        printf "\n${YELLOW}找到備份目錄: %s${NC}\n" "$backup_dir"
        printf "${BLUE}備份檔案列表:${NC}\n"
        ls -la "$backup_dir/"
        
        printf "${YELLOW}是否要刪除所有備份檔案？[y/N]: ${NC}"
        read -r reply
        case "$reply" in
            [Yy]*)
                printf "${YELLOW}移除備份目錄...${NC}\n"
                rm -rf "$backup_dir" &
                spinner $! "清理備份"
                printf "${GREEN}✓ 已清理所有備份${NC}\n"
                ;;
            *)
                printf "${BLUE}保留備份檔案${NC}\n"
                ;;
        esac
    fi
}

# 檢查相關檔案 (簡化版)
check_related_files() {
    printf "\n${YELLOW}掃描相關檔案...${NC}\n"
    
    # 簡單檢查幾個常見位置
    for dir in "$HOME" "/usr/share" "/usr/local/share" "/opt"; do
        if [ -d "$dir" ]; then
            find "$dir" -name "*gamemod*" -type f 2>/dev/null | head -5 | while read -r file; do
                if [ -f "$file" ]; then
                    printf "${YELLOW}發現相關檔案: %s${NC}\n" "$file"
                fi
            done
        fi
    done
}

# 顯示統計
show_stats() {
    local removed_count=$1
    local kept_count=$2
    
    printf "\n${PURPLE}╔═══════════════════════════════════════╗${NC}\n"
    printf "${PURPLE}║           📊 解除安裝統計            ║${NC}\n"
    printf "${PURPLE}╚═══════════════════════════════════════╝${NC}\n"
    
    printf "\n${BLUE}移除的檔案: ${GREEN}%d${NC}\n" "$removed_count"
    printf "${BLUE}保留的檔案: ${YELLOW}%d${NC}\n" "$kept_count"
    
    if [ "$removed_count" -gt 0 ]; then
        printf "\n${GREEN}🎉 gamemod 已成功解除安裝！${NC}\n"
    else
        printf "\n${YELLOW}⚠ 沒有檔案被移除${NC}\n"
    fi
}

# 主解除安裝流程
main() {
    show_title
    progress_bar 0.02 "初始化解除安裝程序"
    
    # 尋找安裝
    printf "\n${YELLOW}步驟 1/4: 尋找安裝位置${NC}\n"
    installations=$(find_installation)
    
    if [ -z "$installations" ]; then
        printf "${YELLOW}未找到 gamemod 安裝${NC}\n"
        check_related_files
        exit 0
    fi
    
    # 將找到的路徑轉換為陣列 (兼容 ash)
    old_IFS="$IFS"
    IFS=' '
    set -- $installations
    IFS="$old_IFS"
    
    installation_count=0
    for path do
        installation_count=$((installation_count + 1))
    done
    
    # 顯示找到的安裝
    printf "\n${GREEN}找到 %d 個安裝:${NC}\n" "$installation_count"
    i=1
    for path in $installations; do
        printf "  ${CYAN}%d) %s${NC}\n" "$i" "$path"
        i=$((i + 1))
    done
    
    # 選擇解除安裝方式
    printf "\n${YELLOW}步驟 2/4: 選擇解除安裝方式${NC}\n"
    printf "  ${CYAN}1${NC}) 移除所有找到的安裝\n"
    printf "  ${CYAN}2${NC}) 選擇性移除\n"
    printf "  ${CYAN}3${NC}) 只移除特定位置\n"
    printf "  ${CYAN}4${NC}) 取消解除安裝\n"
    
    printf "${BLUE}請選擇 [1-4]: ${NC}"
    read -r choice
    
    removed_count=0
    kept_count=0
    
    case "$choice" in
        1)
            # 移除所有
            printf "\n${YELLOW}移除所有安裝...${NC}\n"
            for target in $installations; do
                if uninstall_single "$target"; then
                    removed_count=$((removed_count + 1))
                else
                    kept_count=$((kept_count + 1))
                fi
            done
            ;;
        2)
            # 選擇性移除
            printf "\n${YELLOW}選擇要移除的安裝 (輸入號碼，多個用空格分隔):${NC}\n"
            printf "${BLUE}選擇: ${NC}"
            read -r selections
            
            for selection in $selections; do
                # 找到對應的路徑
                index=1
                target_path=""
                for path in $installations; do
                    if [ "$index" -eq "$selection" ]; then
                        target_path="$path"
                        break
                    fi
                    index=$((index + 1))
                done
                
                if [ -n "$target_path" ]; then
                    if uninstall_single "$target_path"; then
                        removed_count=$((removed_count + 1))
                    else
                        kept_count=$((kept_count + 1))
                    fi
                else
                    printf "${RED}無效選擇: %s${NC}\n" "$selection"
                fi
            done
            ;;
        3)
            # 自訂位置
            printf "\n${YELLOW}輸入要移除的完整路徑:${NC}\n"
            printf "${BLUE}路徑: ${NC}"
            read -r custom_path
            
            if [ -f "$custom_path" ]; then
                if uninstall_single "$custom_path"; then
                    removed_count=$((removed_count + 1))
                else
                    kept_count=$((kept_count + 1))
                fi
            else
                printf "${RED}檔案不存在: %s${NC}\n" "$custom_path"
            fi
            ;;
        4)
            printf "\n${BLUE}解除安裝已取消${NC}\n"
            exit 0
            ;;
        *)
            printf "\n${RED}無效選擇${NC}\n"
            exit 1
            ;;
    esac
    
    # 步驟 3: 清理備份
    progress_bar 0.01 "完成解除安裝程序"
    
    # 步驟 4: 檢查相關檔案
    printf "\n${YELLOW}步驟 3/4: 檢查相關檔案${NC}\n"
    check_related_files
    
    # 步驟 5: 清理選項
    printf "\n${YELLOW}步驟 4/4: 清理選項${NC}\n"
    cleanup_backups
    
    # 顯示統計
    show_stats "$removed_count" "$kept_count"
    
    # 最終建議
    if [ "$removed_count" -gt 0 ]; then
        printf "\n${BLUE}建議:${NC}\n"
        printf "1. 重新整理 shell: ${CYAN}exec \$SHELL${NC}\n"
        printf "2. 確認移除: ${CYAN}which gamemod${NC}\n"
        printf "3. 或: ${CYAN}command -v gamemod${NC}\n"
    fi
    
    printf "\n${GREEN}解除安裝程序完成！${NC}\n"
}

# 錯誤處理
trap 'printf "\n${RED}解除安裝中斷！${NC}\n"; exit 1' INT TERM

# 執行主程序
main