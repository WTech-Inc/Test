window.addEventListener('DOMContentLoaded',()=>{
    setInterval(()=>{
    //display nows times
    const date = new Date();
    let hours = date.getHours();
    let mins = date.getMinutes();
    let secs = date.getSeconds();
    document.getElementById('nowTimes').innerHTML=`Now is : ${hours}:${mins}:${secs}`;
    if (hours < 12 && hours >= 1) {
        document.getElementById('changeWords').innerHTML='Morning';
    } else if(hours >=12 && hours <=18) {
        document.getElementById('changeWords').innerHTML='Afternoon';
    } else if (hours >18 && hours <= 0) {
        document.getElementById('changeWords').innerHTML='Evening';
    }
  },1000)
})

//display username
const addUserName = () => {
    let username = prompt('Please enter your username:');
    if (username == null || !username) return;
    document.getElementById('username').innerHTML=`${username}!`;
}

const pickColor = () => {
    let colorSelector = document.getElementById('colorSelector');
    if (colorSelector != null) {
        let colorPicker = prompt('Please select Red , Blue, Green','Red').toLowerCase();
        switch (colorPicker) {
            case 'red':
                colorSelector.innerHTML='Your choose red';
                colorSelector.style.color='rgb(255,0,0)';
                break;
            case 'blue':
                colorSelector.innerHTML='Your choose blue';
                colorSelector.style.color='rgb(0,0,255)';
                break;
            case 'green':
                colorSelector.innerHTML='Your choose green';
                colorSelector.style.color='rgb(0,255,0)';
                break;
        }
    }
}

const pickImage = () => {
    let imgSelector = document.getElementById('imgSelector');
    if (imgSelector != null) {
        let imgPicker = prompt('Please select : \n1 = FirstImage , \n2 = SecondImage , \n3 = ThirdImage','1');
        switch (imgPicker) {
            case '1':
                imgSelector.src='img/colorPositive.jpg';
                break;
            case '2':
                imgSelector.src='img/colorNegative.jpg';
                break;
            case '3':
                imgSelector.src='img/monoPositive.jpg';
                break;
        }
    }
}